import { stringResponse } from "@/utils/Response";

export const GET = async () => {
  return stringResponse("API is working...!");
};
